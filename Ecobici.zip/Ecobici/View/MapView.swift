//
//  MapView.swift
//  Ecobici
//
//  Created by Pablo Ramirez on 1/30/19.
//  Copyright © 2019 Pablo Ramirez. All rights reserved.
//

import Foundation
import UIKit
import GoogleMaps

public class MapView: UIView, GMSMapViewDelegate{
    
    var map: GMSMapView!
    var referenceMapController: MapController!
    
    let subview: UIView = UIView()
    let indicatorView: UIActivityIndicatorView = UIActivityIndicatorView()
    
    var view: UIView!
    
    func initView(reference: MapController, view: UIView) -> UIView{
        self.view = view
        
        self.referenceMapController = reference
        view.backgroundColor = UIColor(rgba: barColor)
        
        let statusBarHeight = UIApplication.shared.statusBarFrame.height
        
        let titleView: UIView = UIView(frame: CGRect(x: 0, y: statusBarHeight, width: view.frame.width, height: view.frame.height * 0.075))
        titleView.backgroundColor = UIColor(rgba: barColor)
        view.addSubview(titleView)
        
        let titleLabel: UILabel = UILabel(frame: CGRect(x: 0, y: 0, width: titleView.frame.width, height: titleView.frame.height))
        titleLabel.text = "Mapa Ecobici"
        titleLabel.font = titleLabel.font.withSize(regularFontSize)
        titleLabel.textAlignment = .center
        titleView.addSubview(titleLabel)
        
        //////////////////// Map View
        
        let myLocation = getCurrentLocation()
        var camera = GMSCameraPosition()
        
        if(!checkPermissions()){
            
            camera = GMSCameraPosition.camera(withLatitude: 19.3039965, longitude: -99.2108294, zoom: 11.12)
            checkPermissionsAlert()
            
        } else {
            camera = GMSCameraPosition.camera(withLatitude: myLocation.coordinate.latitude, longitude: myLocation.coordinate.longitude, zoom: 14.0)
        }
        
        map = GMSMapView.map(withFrame: CGRect.zero, camera: camera)
        map.frame = CGRect(x: 0, y: titleView.frame.height + titleView.frame.origin.y, width: view.frame.width, height: view.frame.height - titleView.frame.height - titleView.frame.origin.y)
        map.isMyLocationEnabled = true
        map.delegate = self
        map.settings.myLocationButton = true
        
        view.addSubview(map)
        
        //////////////////// Loader Interface
        
        subview.frame = CGRect(x: 0, y: 0, width: view.frame.width, height: view.frame.height)
        subview.backgroundColor = UIColor.black
        subview.alpha = 0.5
        subview.tag = 101
        subview.isHidden = true
        view.addSubview(subview)
        
        indicatorView.frame = CGRect(x: 0, y: 0, width: 100, height: 100)
        indicatorView.center = CGPoint(x: view.frame.width * 0.5, y: view.frame.height * 0.5)
        indicatorView.activityIndicatorViewStyle = .gray
        indicatorView.tag = 102
        indicatorView.isHidden = true
        view.addSubview(indicatorView)
        
        return view
    }
    
    func showDetailsMarker(userData: [String:AnyObject]){
        let detailsView: UIView = UIView(frame: CGRect(x: view.frame.width * 0.05, y: view.frame.height, width: view.frame.width * 0.9, height: view.frame.height * 0.25))
        detailsView.backgroundColor = UIColor.white
        view.addSubview(detailsView)
        
        UIView.animate(withDuration: 0.5, animations: {
            detailsView.frame.origin.y = self.view.frame.height - detailsView.frame.height
        })
    }
    
    func showMarkersStations(stations: [[String:AnyObject]]){
        for station in stations{
            if let location = station["location"] as? [String:AnyObject]{
                let latitude: Double = location["lat"] as! Double
                let longitude: Double = location["lon"] as! Double
                let name: String = station["name"] as! String
                let address: String = station["address"] as! String
                let stationType: String = station["stationType"] as! String
                
                let marker = GMSMarker()
                marker.position = CLLocationCoordinate2D(latitude: latitude, longitude: longitude)
                marker.map = map
                marker.userData = [
                    "name": name,
                    "address": address,
                    "stationType": stationType
                ]
            }
        }
    }
    
    func mapView(_ mapView: GMSMapView, didTap marker: GMSMarker) -> Bool {
        
        let camera: GMSCameraPosition = GMSCameraPosition.camera(withLatitude: marker.position.latitude, longitude: marker.position.longitude, zoom: 18.0)
        map.animate(to: camera)
        mapView.delegate = self
        
        if let userData = marker.userData as? [String:AnyObject] {
            print("name = \(userData["name"])")
            showDetailsMarker(userData: userData)
        }
        
        return true
    }
    
    public func didTapMyLocationButton(for mapView: GMSMapView) -> Bool {
        
        
        return true
    }
    
    public func mapView(_ mapView: GMSMapView, didTap overlay: GMSOverlay) {
        print("tap en el mapa")
    }
    
    func showLoader(){
        subview.isHidden = false
        indicatorView.isHidden = false
        indicatorView.startAnimating()
    }
    
    func hideLoader(){
        subview.isHidden = true
        indicatorView.isHidden = true
    }
    
    func showAlertError(reference: MapController, titleText: String, textMessage: String){
        let alertController = UIAlertController(title: titleText, message: textMessage, preferredStyle: .alert)
        let acceptAction = UIAlertAction(title: "Aceptar", style: .default) { (action: UIAlertAction) in
            print("Accept Action");
            
            alertController.dismiss(animated: true, completion: nil)
        }
        
        alertController.addAction(acceptAction)
        reference.present(alertController, animated: true, completion: nil)
    }
    
    func checkPermissionsAlert(){
        let alertController = UIAlertController(title: NSLocalizedString("Aviso", comment: ""), message: NSLocalizedString("Activa tu GPS para poder usar esta sección", comment: ""), preferredStyle: .alert)
        
        let cancelAction = UIAlertAction(title: NSLocalizedString("Cancel", comment: ""), style: .cancel, handler: nil)
        let settingsAction = UIAlertAction(title: NSLocalizedString("Configuraciones", comment: ""), style: .default) { (UIAlertAction) in
            if let url = URL(string:UIApplicationOpenSettingsURLString) {
                if #available(iOS 10.0, *) {
                    UIApplication.shared.open(url, options: [:])
                } else {
                    UIApplication.shared.openURL(url)
                }
            }
        }
        
        alertController.addAction(settingsAction)
        alertController.addAction(cancelAction)
        referenceMapController.present(alertController, animated: true, completion: nil)
    }
    
}
