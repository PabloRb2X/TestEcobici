//
//  MapController.swift
//  Ecobici
//
//  Created by Pablo Ramirez on 1/30/19.
//  Copyright © 2019 Pablo Ramirez. All rights reserved.
//

import UIKit

class MapController: UIViewController {
    
    let mapView: MapView = MapView()

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        initView()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        mapView.showLoader()
        serviceManager.stationsService(referenceController: self)
    }
    
    func initView(){
        
        self.view = mapView.initView(reference: self, view: self.view)
    }
    
    func showStationsInMap(stations: [[String:AnyObject]]){
        mapView.hideLoader()
        
        print("show markers")
        mapView.showMarkersStations(stations: stations)
    }
    
    func errorsEvents(){
        mapView.hideLoader()
        ////////////////////// Mostrar una ventana de error
        
        mapView.showAlertError(reference: self, titleText: "Error", textMessage: "Error al cargar las estaciones cercanas")
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
